# Residencial Los Robles – Sprint 1 (React + Vite)

Este repositorio contiene el código de ejemplo para el Sprint 1 del proyecto: login, estado de cuenta y pagos (demo).

## Requisitos
- Node.js 18+
- npm

## Arranque
```bash
npm install
npm run dev
```

## Estructura
- `src/components/Login.jsx`: acceso de usuarios (simulado).
- `src/components/Dashboard.jsx`: estado de cuenta, pagos y notificaciones.
- `src/components/Payments.jsx`: flujo de pago simulado.
- `src/components/Notifications.jsx`: listado de avisos.

## Sprint Planning (Resumen)
- Objetivo: habilitar login, estado de cuenta y pagos demo.
- Duración: 2 semanas.
- Criterios de terminado: usuarios pueden iniciar sesión, ver adeudos y marcar pago simulado.

## Próximos sprints
- Integración real con pasarela de pago.
- Módulo de votaciones.
- Módulo de emergencias.

## Enlace al repositorio
- Reemplaza este texto con tu URL de GitHub después de hacer push.
