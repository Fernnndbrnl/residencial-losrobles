import React, { useState } from 'react'

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    // Demo: autenticación simulada
    if (email && password) {
      onLogin({ id: 1, name: 'María López', email })
    } else {
      setError('Ingresa correo y contraseña.')
    }
  }

  return (
    <div style={{ marginTop: 24 }}>
      <h2>Acceso de residentes</h2>
      <form onSubmit={handleSubmit} style={{ display: 'grid', gap: 12, maxWidth: 360 }}>
        <label>Correo
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="tu@correo.com" />
        </label>
        <label>Contraseña
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" />
        </label>
        {error && <div style={{ color: 'crimson' }}>{error}</div>}
        <button type="submit">Entrar</button>
      </form>
    </div>
  )
}
