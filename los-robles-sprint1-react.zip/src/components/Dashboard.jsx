import React, { useState } from 'react'
import Payments from './Payments.jsx'
import Notifications from './Notifications.jsx'

const mockLedger = [
  { id: 1, concept: 'Cuota mantenimiento Sept', amount: 800, status: 'Pagado' },
  { id: 2, concept: 'Cuota mantenimiento Oct', amount: 800, status: 'Pendiente' },
]

export default function Dashboard({ user }) {
  const [ledger, setLedger] = useState(mockLedger)

  function onPaymentSuccess(newPayment) {
    setLedger(prev => prev.map(item => item.id === newPayment.invoiceId ? { ...item, status: 'Pagado' } : item))
  }

  return (
    <div style={{ marginTop: 24 }}>
      <p>Bienvenida/o, <strong>{user.name}</strong></p>

      <section style={{ marginTop: 16 }}>
        <h3>Estado de cuenta</h3>
        <table border="1" cellPadding="8">
          <thead>
            <tr>
              <th>Concepto</th><th>Monto</th><th>Estado</th>
            </tr>
          </thead>
          <tbody>
            {ledger.map(row => (
              <tr key={row.id}>
                <td>{row.concept}</td>
                <td>${row.amount}.00 MXN</td>
                <td>{row.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section style={{ marginTop: 24 }}>
        <Payments invoices={ledger} onSuccess={onPaymentSuccess} />
      </section>

      <section style={{ marginTop: 24 }}>
        <Notifications />
      </section>
    </div>
  )
}
