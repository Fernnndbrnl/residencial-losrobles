import React, { useMemo, useState } from 'react'

export default function Payments({ invoices, onSuccess }) {
  const pending = useMemo(() => invoices.filter(i => i.status === 'Pendiente'), [invoices])
  const [invoiceId, setInvoiceId] = useState(pending[0]?.id || '')
  const [method, setMethod] = useState('Tarjeta')
  const [processing, setProcessing] = useState(false)
  const [msg, setMsg] = useState('')

  function pay() {
    if (!invoiceId) return
    setProcessing(true)
    setTimeout(() => {
      setProcessing(false)
      onSuccess({ invoiceId: Number(invoiceId) })
      setMsg('Pago registrado (simulado). Recibo enviado al correo.')
    }, 800)
  }

  return (
    <div>
      <h3>Pagos</h3>
      {pending.length === 0 ? (
        <p>No tienes adeudos pendientes.</p>
      ) : (
        <div style={{ display: 'grid', gap: 8, maxWidth: 420 }}>
          <label>Selecciona adeudo
            <select value={invoiceId} onChange={e => setInvoiceId(e.target.value)}>
              {pending.map(p => (
                <option key={p.id} value={p.id}>{p.concept} - ${p.amount}.00</option>
              ))}
            </select>
          </label>
          <label>Método de pago
            <select value={method} onChange={e => setMethod(e.target.value)}>
              <option>Tarjeta</option>
              <option>Transferencia</option>
              <option>PayPal</option>
            </select>
          </label>
          <button onClick={pay} disabled={processing}>Confirmar pago</button>
          {msg && <div style={{ color: 'green' }}>{msg}</div>}
        </div>
      )}
    </div>
  )
}
