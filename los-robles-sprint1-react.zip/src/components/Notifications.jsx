import React, { useState } from 'react'

export default function Notifications() {
  const [items] = useState([
    { id: 1, title: 'Fumigación general', body: 'Sábado 10:00 am. Mantén ventanas cerradas.' },
    { id: 2, title: 'Asamblea', body: 'Domingo 6 pm. Votación de presupuesto 2025.' },
  ])

  return (
    <div>
      <h3>Notificaciones</h3>
      <ul>
        {items.map(n => (
          <li key={n.id}>
            <strong>{n.title}:</strong> {n.body}
          </li>
        ))}
      </ul>
    </div>
  )
}
