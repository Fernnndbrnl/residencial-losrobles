import React, { useState } from 'react'
import Login from './components/Login.jsx'
import Dashboard from './components/Dashboard.jsx'

export default function App() {
  const [user, setUser] = useState(null)

  return (
    <div style={{ fontFamily: 'system-ui, Arial', maxWidth: 960, margin: '0 auto', padding: 24 }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Residencial Los Robles</h1>
        {user && (
          <button onClick={() => setUser(null)}>Cerrar sesión</button>
        )}
      </header>

      {!user ? (
        <Login onLogin={setUser} />
      ) : (
        <Dashboard user={user} />
      )}

      <footer style={{ marginTop: 32, fontSize: 12, color: '#555' }}>
        Sprint 1 · Login, Estado de cuenta y Pagos (demo)
      </footer>
    </div>
  )
}
